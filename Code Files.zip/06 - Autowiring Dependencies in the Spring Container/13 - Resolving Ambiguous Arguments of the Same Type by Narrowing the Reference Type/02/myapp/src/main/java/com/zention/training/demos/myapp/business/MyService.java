package com.zention.training.demos.myapp.business;

public interface MyService {
    void doBusinessLogic();
}
