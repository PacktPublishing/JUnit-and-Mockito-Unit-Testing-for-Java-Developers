package com.zention.training.demos.myapp.data;

public interface MyRepository {
    void doQuery();
}
