package com.zention.training.demos.myapp;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.zention.training.demos.myapp")
public class AppConfig {

}
