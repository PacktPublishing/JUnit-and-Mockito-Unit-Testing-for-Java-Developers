package com.zention.training.demos.myapp.data;

import org.springframework.stereotype.Repository;

@Repository
public class SomeOtherRepositoryImpl implements MyRepository {

    @Override
    public void doQuery() {
        System.out.println("Doing DB query!");
    }

}
