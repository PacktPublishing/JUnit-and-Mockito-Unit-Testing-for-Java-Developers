package com.zention.training.demos.myapp;

public interface MyService {
    void doBusinessLogic();
}
