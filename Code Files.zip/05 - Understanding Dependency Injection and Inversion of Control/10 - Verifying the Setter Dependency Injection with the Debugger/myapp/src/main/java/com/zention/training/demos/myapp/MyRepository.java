package com.zention.training.demos.myapp;

public class MyRepository {

    public void doQuery() {
        System.out.println("Doing DB query!");
    }

}
