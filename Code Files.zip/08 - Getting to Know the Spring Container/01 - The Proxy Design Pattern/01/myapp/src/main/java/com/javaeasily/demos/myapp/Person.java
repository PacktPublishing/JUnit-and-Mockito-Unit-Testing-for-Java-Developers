package com.javaeasily.demos.myapp;

public class Person {
    void greet() {
        System.out.println("Hello there!");
    }
}
