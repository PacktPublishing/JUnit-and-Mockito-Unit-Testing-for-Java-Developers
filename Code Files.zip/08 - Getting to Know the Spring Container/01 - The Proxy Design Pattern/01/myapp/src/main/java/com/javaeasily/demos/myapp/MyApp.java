package com.javaeasily.demos.myapp;

public class MyApp {

    public static void main(String[] args) {
        new Person().greet();
    }

}
