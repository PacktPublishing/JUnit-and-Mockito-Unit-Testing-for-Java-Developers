package com.javaeasily.demos.myapp;

public interface Person {
    void greet();
    void greetInFrench();
}
